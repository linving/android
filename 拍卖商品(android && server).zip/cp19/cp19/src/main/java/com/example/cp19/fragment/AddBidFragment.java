package com.example.cp19.fragment;

import android.annotation.SuppressLint;
import android.app.Fragment;

@SuppressLint("NewApi")
public class AddBidFragment extends Fragment {

}
