package com.example.cp19;

import android.app.Fragment;

public class ViewBid extends FragmentActivity
{

    @Override
    protected Fragment getFragment()
    {
        return null;
    }
}
