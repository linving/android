package com.example.cp19.fragment;

import android.annotation.TargetApi;
import android.app.Fragment;
import android.os.Build;

@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public class ChooseKindFragment extends Fragment {

}
