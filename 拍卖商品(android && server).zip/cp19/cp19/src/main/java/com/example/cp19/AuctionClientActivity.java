/*
 * Copyright (C) 2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.cp19;

import com.example.cp19.fragment.AddBidFragment;
import com.example.cp19.fragment.AuctionListFragment;
import com.example.cp19.fragment.ChooseKindFragment;
import com.example.cp19.fragment.ManageItemFragment;
import com.example.cp19.fragment.ManageKindFragment;
import com.example.cp19.fragment.ViewItemFragment;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;

/**
 * @author jiazhixin
 */
@SuppressLint("NewApi")
public class AuctionClientActivity extends BaseActivity implements Callbacks {

	// 定义一个旗标，用于表示应用支持最大屏幕
	private boolean mTwoPane;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// 指定加载R.layout.activity_main.xml 布局文件
		// 实际会根据应用会根据手机屏幕分辨率实现加载不同文件
		setContentView(R.layout.activity_main);
		// 如果加载界面布局文件中包含的Id 为book_detail_container 的组件
		if (findViewById(R.id.auction_detail_container) != null) {	
			mTwoPane = true;
			((AuctionListFragment) getFragmentManager().findFragmentById(
					R.id.auction_list)).setActivateOnItemClick(true);
		}
	}

	@Override
	public void onItemSelected(Integer id, Bundle bundle) {
		if (mTwoPane) {
			Fragment fragment = null;
			switch ((int) id) {
			// 查看竞得物品
			case 0:
				// 创建ViewItemFragment
				fragment = new ViewItemFragment();
				// 创建Bundle 向fragment 传入参数
				Bundle arguments = new Bundle();
				arguments.putString("action", "/item/itemgivelist");
				fragment.setArguments(arguments);
				break;
			// 浏览竞拍物品
			case 1:
				// 创建ViewItemFragment
				fragment = new ViewItemFragment();
				// 创建Bundle 向fragment 传入参数
				Bundle arguments2 = new Bundle();
				arguments2.putString("action", "/item/itemlist");
				fragment.setArguments(arguments2);
				break;
			// 管理物品种类
			case 2:
				// 创建ManageKindFragment
				fragment = new ManageKindFragment();
				break;
			// 管理物品
			case 3:
				// 创建ManageItemFragment
				fragment = new ManageItemFragment();
				break;
			// 浏览拍卖物品(选择物品种类)
			case 4:
				// 创建ManageItemFragment
				fragment = new ChooseKindFragment();
				break;
			case 5:
				// 创建ViewBidFragment
				fragment = new AddBidFragment();
				break;
			}
			// 使用fragment 替换auction_detail_container 容器当前显示的fragment
			getFragmentManager().beginTransaction()
					.replace(R.id.auction_detail_container, fragment)
					.addToBackStack(null).commit();
		} else {
			Intent intent = null;
			switch ((int) id) {
			// 查看竞得物品
			case 0:
				// 启动ViewItem
				intent = new Intent(this,ViewItem.class);
				// action 属性请求servlet 地址
				intent.putExtra("action", "/item/itemgivelist");
				startActivity(intent);
				break;
			// 浏览竞拍物品
			case 1:
				// 启动ViewItem
				intent = new Intent(this,ViewItem.class);
                // action 属性请求servlet 地址
                intent.putExtra("action", "/item/itemlist");
				startActivity(intent);
				break;
			// 管理物品种类
			case 2:
				// 启动ManageKind
				intent = new Intent(this,ManageKind.class);
				startActivity(intent);
				break;
			// 管理物品
			case 3:
				// 启动ManangeItem
				intent = new Intent(this,ManageItem.class);
				startActivity(intent);
				break;
			// 浏览拍卖物品(选择物品种类)
			case 4:
				// 启动ChooseKind
				intent = new Intent(this,ChooseKind.class);
				startActivity(intent);
				break;
			// 查看自己竞标
			case 5:
				// 创建ViewBid
				intent = new Intent(this,ViewBid.class);
				startActivity(intent);
				break;
			}
		}
	}

}
