package com.example.cp19.adapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.cp19.R;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class JSONArrayAdapter extends BaseAdapter {

	private Context ctx;
	private JSONArray jsonArray;
	private String property;
	private boolean hasIcon;
	
	public JSONArrayAdapter(Context ctx, JSONArray jsonArray,
			String property, boolean hasIcon) {
		this.ctx = ctx;
		this.jsonArray = jsonArray;
		this.property = property;
		this.hasIcon = hasIcon;
	}

	@Override
	public int getCount() {
		return jsonArray.length();
	}

	@Override
	public Object getItem(int position) {
		return jsonArray.optJSONObject(position);
	}

	@Override
	public long getItemId(int position) {
		try {
			return ((JSONObject)getItem(position)).getInt("id");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
		}
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// 定义一个线性布局管理器
		LinearLayout linear = new LinearLayout(ctx);
		// 设置为水平的线性布局
		linear.setOrientation(0);
		// 创建ImageView
		ImageView iv = new ImageView(ctx);
		iv.setPadding(10, 0, 20, 0);
		iv.setImageResource(R.drawable.item);
		// 将图片添加到Linearlayout中
		linear.addView(iv);
		
		TextView tv = new TextView(ctx);
		
		
		try {
			String itemName = ((JSONObject)getItem(position)).getString(property);
			tv.setText(itemName);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		tv.setTextSize(20);
		if(hasIcon) {
			linear.addView(tv);
			return linear;
		} else {
			tv.setTextColor(Color.BLACK);
			return tv;
		}
	}

}
