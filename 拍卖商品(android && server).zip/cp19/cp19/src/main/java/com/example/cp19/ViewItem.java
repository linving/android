package com.example.cp19;


import android.annotation.TargetApi;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;

import com.example.cp19.fragment.ViewItemFragment;

public class ViewItem extends FragmentActivity {


    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    @Override
    protected Fragment getFragment() {
        ViewItemFragment fragment = new ViewItemFragment();
        Bundle arguments = new Bundle();
        arguments.putString("action", getIntent().getStringExtra("action"));
        fragment.setArguments(arguments);
        return fragment;
    }
}
