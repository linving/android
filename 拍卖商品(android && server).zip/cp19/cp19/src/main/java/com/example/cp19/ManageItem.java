package com.example.cp19;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;

import com.example.cp19.fragment.ManageItemFragment;

public class ManageItem extends FragmentActivity implements  Callbacks {

    @Override
    protected Fragment getFragment() {
        return new ManageItemFragment();
    }

    @Override
    public void onItemSelected(Integer id, Bundle bundle) {
        Intent intent = new Intent(this , AddItem.class);
        startActivity(intent);
    }
}
