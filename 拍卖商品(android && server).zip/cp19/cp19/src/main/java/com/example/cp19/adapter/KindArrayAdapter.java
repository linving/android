package com.example.cp19.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.cp19.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class KindArrayAdapter extends BaseAdapter {

    private Context ctx;
    private JSONArray kindArray;

    public KindArrayAdapter(JSONArray jsonArray, Context ctx) {
        this.ctx = ctx;
        this.kindArray = jsonArray;
    }

    @Override
	public int getCount() {

		return kindArray.length();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return kindArray.optJSONObject(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
        try {
            return ((JSONObject)getItem(position)).getInt("id");
        } catch (JSONException e) {
            e.printStackTrace();
        }
          return -1;
    }

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
        // 定义一个线性布局管理器
        LinearLayout container = new LinearLayout(ctx);
        // 设置为水平的线性布局
        container.setOrientation(0);
        // 定义一个线性布局管理器
        LinearLayout linear = new LinearLayout(ctx);
        // 设置为水平的线性布局
        linear.setOrientation(0);
        // 创建ImageView
        ImageView iv = new ImageView(ctx);
        iv.setPadding(10, 0, 20, 0);
        iv.setImageResource(R.drawable.item);
        linear.addView(iv);

        TextView tv = new TextView(ctx);

        String itemName = null;
        try {
            itemName = ((JSONObject)getItem(position)).getString("kindName");
            tv.setText(itemName);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        tv.setTextSize(20);
        linear.addView(tv);
        container.addView(linear);

        TextView descView = new TextView(ctx);
        descView.setPadding(30,0,0,0);
        try {
            String  kindDesc = ((JSONObject)getItem(position)).getString("kindDesc");
            descView.setText(kindDesc);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        descView.setTextSize(16);
        container.addView(descView);

        return container;
	}

}
