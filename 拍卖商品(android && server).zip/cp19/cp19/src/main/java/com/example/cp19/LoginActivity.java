/*
 * Copyright (C) 2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.cp19;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.cp19.api.Api;
import com.example.cp19.listener.HomeListener;
import com.example.cp19.utils.DialogUtil;
import com.example.cp19.utils.HttpUtil;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.ExecutionException;
import  java.util.*;

/**
 * Created by apple on 15-3-18.
 * @author jiazhixin
 */
public class LoginActivity extends  BaseActivity {


    // 定义两个文本框
    private EditText etName,etPass;
    // 定义两个按钮
    private Button bnLogin,bnCancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        // 获取界面两个编辑框
        etName = (EditText) findViewById(R.id.userEditText);
        etPass = (EditText) findViewById(R.id.pwdEditText);
        // 获取界面中两个按钮
        bnLogin = (Button) findViewById(R.id.bnLogin);
        bnCancel = (Button) findViewById(R.id.bnCancel);
        // 为bnCancal 按钮的单击事件绑定事件监听器
        bnCancel.setOnClickListener(new HomeListener(this));
        bnLogin.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // 检测合法性
                if(validate()) {
                    if(loginPro()) {
                        Intent intent = new Intent(LoginActivity.this, AuctionClientActivity.class);
                        startActivity(intent);
                        // 结束该activity
                        finish();
                    } else {
                        DialogUtil.showDialog(LoginActivity.this, "用户名或者密码错误，请重新输入", false);
                    }
                }
            }


        });
    }

    private boolean validate() {
        String username = etName.getText().toString().trim();
        if(username.equals("")) {
            DialogUtil.showDialog(this, "用户账号是必填项",false);
            return false;
        }
        String pwd = etPass.getText().toString().trim();
        if(pwd.equals("")) {
            DialogUtil.showDialog(this, "用户口令是必填项",false);
            return false;
        }
        return true;
    }

    private boolean loginPro() {
        // 获取用户输入用户名密码
        String username = etName.getText().toString();
        String pwd = etPass.getText().toString();

        JSONObject jsonObj;
        try{
            jsonObj = query(username,pwd);

            // 判断userId 大于 0
            if(jsonObj.getInt("status") == 200) {
                return true;
            }
        } catch (Exception e) {
            DialogUtil.showDialog(this,"服务器响应异常，请稍后再试",false);
            e.printStackTrace();
        }
        return false;
    }

    private JSONObject query(String username, String pwd) throws JSONException, InterruptedException, ExecutionException {
        // 封装请求参数
        Map<String,String> map = new HashMap<String, String>();
        map.put("name", username);
        map.put("pwd", pwd);
        // 发送请求
        return new JSONObject(HttpUtil.postRequest(Api.LOGIN, map));
    }
}
