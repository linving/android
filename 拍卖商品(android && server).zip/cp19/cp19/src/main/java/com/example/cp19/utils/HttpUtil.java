/*
 * Copyright (C) 2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.cp19.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

/**
 * @author jiazhixin
 */

public class HttpUtil {

	// 创建httpClient 对象
	public static HttpClient httpClinet = new DefaultHttpClient();
	public final static String BASE_URL = "http://192.168.1.14:9090/cp19server/api";
	
	/**
	 * 
	 * @param url 发送请求 url
	 * @return 服务器返回字符串
	 * @throws InterruptedException
	 * @throws java.util.concurrent.ExecutionException
	 */
	public static String getRequest(final String url) throws InterruptedException, ExecutionException {
		FutureTask<String> task = new FutureTask<String>(
					new Callable<String>() {

						@Override
						public String call() throws Exception {
							// 创建httpGet 对象
							HttpGet get = new HttpGet(url);
							// 发送httpGet 对象
							HttpResponse httpResponse = httpClinet.execute(get);
							// 服务器返回响应
							if(httpResponse.getStatusLine().getStatusCode() == 200) {
								// 获取服务器返回成功响应
								String result = EntityUtils.toString(httpResponse.getEntity());
								return result;
							}
							return null;
						}
					});
		 new Thread(task).start();
		 return task.get();
	}
	
	
	public static String postRequest(final String url,final Map<String,String> rawParams) throws InterruptedException, ExecutionException {
		FutureTask<String> task = new FutureTask<String>(
				new Callable<String>() {

					@Override
					public String call() throws Exception {
						// 创建HttpPost 对象
						HttpPost post = new HttpPost(url);
						// 如果传入参数个数比较多，可以对参数进行封装
						List<NameValuePair> params = new ArrayList<NameValuePair>();
						for(String key : rawParams.keySet()) {
							params.add(new BasicNameValuePair(key, rawParams.get(key)));
						}
						// 设置请求参数
						post.setEntity(new UrlEncodedFormEntity(params,"UTF-8"));
						// 发送post 请求
						HttpResponse httpResponse = httpClinet.execute(post);
						
						if(httpResponse.getStatusLine().getStatusCode() == 200) {
							// 获取服务器返回成功响应
							String result = EntityUtils.toString(httpResponse.getEntity());
							return result;
						}
						return null;
					}
		});
		 new Thread(task).start();
		 return task.get();
	}
}
