package com.example.cp19.fragment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.cp19.R;
import com.example.cp19.adapter.JSONArrayAdapter;
import com.example.cp19.listener.HomeListener;
import com.example.cp19.utils.DialogUtil;
import com.example.cp19.utils.HttpUtil;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

@SuppressLint("NewApi")
public class ViewItemFragment extends Fragment {

	Button bnHome;
	ListView succList;
	TextView viewTitle;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.view_item, container,false);
		// 获取界面返回按钮
		bnHome = (Button) rootView.findViewById(R.id.bn_home);
		succList = (ListView) rootView.findViewById(R.id.succList);
        viewTitle = (TextView) rootView.findViewById(R.id.view_titile);
		// 返回按钮添加事件监听器
		bnHome.setOnClickListener(new HomeListener(getActivity()));
		String action = getArguments().getString("action");
		// 发送请求URL
		String url = HttpUtil.BASE_URL + action;

		viewTitle.setText(R.string.view_fail);

		try{
			// 发送URL 请求
			JSONArray jsonArray = new JSONArray(HttpUtil.getRequest(url));
			JSONArrayAdapter adapter = new JSONArrayAdapter(getActivity(),jsonArray,"name",true);
			succList.setAdapter(adapter);
		} catch (Exception e) {
			DialogUtil.showDialog(getActivity(), "服务器响应异常，请稍后再试!", false);
			e.printStackTrace();
		}
		
		succList.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				viewItemDetail(position);
			}
		});
		return rootView;
	}

	protected void viewItemDetail(int position) {
		// 加载detail.xml 界面布局代表视图
		View detailView  = getActivity().getLayoutInflater().inflate(R.layout.detail, null);
		TextView itemName = (TextView) detailView.findViewById(R.id.itemName);
		TextView itemKind = (TextView) detailView.findViewById(R.id.itemKind);
		TextView maxPrice = (TextView) detailView.findViewById(R.id.maxPrice);
		TextView itemRemark = (TextView) detailView.findViewById(R.id.itemRemark);
		// 获取被单击的列表项
		JSONObject jsonObj = (JSONObject) succList.getAdapter().getItem(position);
		
		try {
			itemName.setText(jsonObj.getString("name"));
			itemKind.setText(jsonObj.getString("kind"));
			maxPrice.setText(jsonObj.getString("maxPrice"));
			itemRemark.setText(jsonObj.getString("desc"));
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		DialogUtil.showDialog(getActivity(), detailView);
	}
}
