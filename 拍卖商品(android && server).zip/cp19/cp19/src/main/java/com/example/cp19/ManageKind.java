package com.example.cp19;


import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;

import com.example.cp19.fragment.ManageKindFragment;

public class ManageKind extends FragmentActivity  implements  Callbacks {

    @Override
    protected Fragment getFragment() {
        ManageKindFragment kindFragment = new ManageKindFragment();
        return kindFragment;
    }

    @Override
    public void onItemSelected(Integer id, Bundle bundle) {
        Intent i = new Intent(this , AddKind.class);
        startActivity(i);
    }
}
