package com.example.cp19.fragment;

import android.annotation.TargetApi;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import com.example.cp19.R;
import com.example.cp19.listener.HomeListener;
import com.example.cp19.utils.DialogUtil;
import com.example.cp19.utils.HttpUtil;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;

/**
 * Created by apple on 15-3-19.
 * @author jiazhixin
 */
@TargetApi(Build.VERSION_CODES.HONEYCOMB)
public class AddKindFragment extends Fragment {

    EditText kindName,kindDesc;
    Button bnAdd,bnCacel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.add_kind,container,false);
        // 获取界面两个文本框
        kindName = (EditText) rootView.findViewById(R.id.kindName);
        kindDesc = (EditText) rootView.findViewById(R.id.kindDesc);

        bnAdd = (Button)rootView.findViewById(R.id.bnAdd);
        bnCacel = (Button)rootView.findViewById(R.id.bnCancel);
        bnCacel.setOnClickListener(new HomeListener(getActivity()));

        bnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(validate()) {
                    String name = kindName.getText().toString();
                    String desc = kindDesc.getText().toString();

                    String result = null;
                    try {
                        result = addKind(name,desc);
                        DialogUtil.showDialog(getActivity(),result,true);
                    } catch (Exception e) {
                        DialogUtil.showDialog(getActivity(),"服务器响应异常，请稍后再试",false);
                        e.printStackTrace();

                    }
                }
            }
        });
        return rootView;
    }

    private String addKind(String name, String desc) throws ExecutionException, InterruptedException {
        Map<String,String> map = new HashMap<String,String>();
        map.put("kindName",name);
        map.put("kindDesc",desc);

        String url = HttpUtil.BASE_URL + "/kind/addkind";

        return HttpUtil.postRequest(url,map);
    }

    private boolean validate() {
        String name = kindName.getText().toString().trim();
        if(name.equals("")) {
            DialogUtil.showDialog(getActivity(),"种类名称必须填",false);
            return false;
        }
        return true;
    }

}
