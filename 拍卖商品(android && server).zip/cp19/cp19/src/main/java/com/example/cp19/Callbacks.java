package com.example.cp19;

import android.os.Bundle;

public interface Callbacks {

	public void onItemSelected(Integer id, Bundle bundle);
}
