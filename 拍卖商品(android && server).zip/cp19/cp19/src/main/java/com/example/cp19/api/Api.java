package com.example.cp19.api;

import com.example.cp19.utils.HttpUtil;

public class Api {

	public final static String LOGIN = HttpUtil.BASE_URL + "/user/login";
    // 竞拍列表获取
    public final static String ITEM =  HttpUtil.BASE_URL + "/item/itemlist";

}
