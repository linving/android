package com.example.cp19;



import android.annotation.TargetApi;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;

import com.example.cp19.fragment.AddBidFragment;


public class AddBid extends FragmentActivity
{
	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
    @Override
	public Fragment getFragment()
	{
		AddBidFragment fragment = new AddBidFragment();
		Bundle args = new Bundle();
		args.putInt("itemId", getIntent()
			.getIntExtra("itemId", -1));
		fragment.setArguments(args);
		return fragment;
	}
}
