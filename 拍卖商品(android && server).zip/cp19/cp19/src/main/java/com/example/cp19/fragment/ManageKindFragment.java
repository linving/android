package com.example.cp19.fragment;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;

import com.example.cp19.Callbacks;
import com.example.cp19.R;
import com.example.cp19.adapter.KindArrayAdapter;
import com.example.cp19.listener.HomeListener;
import com.example.cp19.utils.DialogUtil;
import com.example.cp19.utils.HttpUtil;

import org.json.JSONArray;


@SuppressLint("NewApi")
public class ManageKindFragment extends Fragment {

    public  static final int ADD_KIND = 0x1007;
    Button bnHome, bnAdd;
    ListView kindList;
    Callbacks mCallbacks;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.manage_kind, container,false);
        bnHome = (Button) rootView.findViewById(R.id.bn_home);
        bnAdd = (Button) rootView.findViewById(R.id.bn_home);
        kindList = (ListView) rootView.findViewById(R.id.kindList);
        bnHome.setOnClickListener(new HomeListener(getActivity()));
        bnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCallbacks.onItemSelected(ADD_KIND,null);
            }
        });

        String url = HttpUtil.BASE_URL + "/kind/kindlist";

        try {
            final JSONArray jsonArray = new JSONArray(HttpUtil.getRequest(url));
            kindList.setAdapter(new KindArrayAdapter(jsonArray,getActivity()));
        } catch (Exception e) {
            DialogUtil.showDialog(getActivity(),"服务器响应异常，请稍后再试",false);
            e.printStackTrace();
        }
        return rootView;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        if(!(activity instanceof  Callbacks)) {
            throw new IllegalStateException("必须实现Callbacks 接口");
        }
        mCallbacks = (Callbacks) activity;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mCallbacks = null;
    }
}
