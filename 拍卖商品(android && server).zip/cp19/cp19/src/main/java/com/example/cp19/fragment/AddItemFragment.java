package com.example.cp19.fragment;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.example.cp19.R;
import com.example.cp19.adapter.JSONArrayAdapter;
import com.example.cp19.listener.HomeListener;
import com.example.cp19.utils.DialogUtil;
import com.example.cp19.utils.HttpUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;

@SuppressLint("NewApi")
public class AddItemFragment extends Fragment {

    // 定义中文文本框
    EditText itemName , itemDesc, itemRemark, initPrice;
    Spinner itemKind,availTime;
    Button bnAdd , bnCancel;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView =inflater.inflate(R.layout.add_item,container,false);

        itemName = (EditText) rootView.findViewById(R.id.itemName);
        itemDesc = (EditText) rootView.findViewById(R.id.itemDesc);
        itemRemark = (EditText) rootView.findViewById(R.id.itemRemark);
        initPrice = (EditText) rootView.findViewById(R.id.initPrice);
        itemKind = (Spinner) rootView.findViewById(R.id.itemKind);
        availTime = (Spinner) rootView.findViewById(R.id.availTime);

        String url = HttpUtil.BASE_URL + "/kind/kindlist";
        JSONArray jsonArray = null;

        try {
            jsonArray = new JSONArray(HttpUtil.getRequest(url));
        } catch (Exception e) {
            e.printStackTrace();
        }
        JSONArrayAdapter adapter = new JSONArrayAdapter(getActivity(),jsonArray,"kindName",false);
        itemKind.setAdapter(adapter);

        bnAdd = (Button) rootView.findViewById(R.id.bnAdd);
        bnCancel = (Button) rootView.findViewById(R.id.bnCancel);
        bnCancel.setOnClickListener(new HomeListener(getActivity()));
        bnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(validate()) {
                    String name = itemName.getText().toString();
                    String desc = itemDesc.getText().toString();
                    String remark = itemRemark.getText().toString();
                    String price = itemRemark.getText().toString();
                    JSONObject kind = (JSONObject) itemKind.getSelectedItem();
                    int avail = availTime.getSelectedItemPosition();

                    switch(avail) {
                        case 5:
                            avail = 7;
                            break;
                        case 6:
                            avail = 30;
                            break;
                        default:
                            avail += 1;
                            break;
                    }
                    String result = null;
                    try {
                        result = addItem(name,desc,remark,price,kind.getInt("id"),avail);
                        DialogUtil.showDialog(getActivity(),result,true);
                    } catch (Exception e) {
                        DialogUtil.showDialog(getActivity(),"服务器响应异常，请稍后再试",false);
                        e.printStackTrace();
                    }


                }
            }
        });
        return rootView;
    }

    private String addItem(String name, String desc, String remark, String price, int id, int avail) throws ExecutionException, InterruptedException {
        Map<String,String> map = new HashMap<String,String>();
        map.put("itemName",name);
        map.put("itemDesc",desc);
        map.put("itemRemark",remark);
        map.put("initPrice",price);
        map.put("kindId",id + "");
        map.put("availTime",avail + "");

        String url = HttpUtil.BASE_URL + "/item/additem";
        return HttpUtil.postRequest(url,map);
    }

    private boolean validate() {
        String name = itemName.getText().toString().trim();
        if(name.equals("")) {
            DialogUtil.showDialog(getActivity(),"物品名称必填项",false);
            return false;
        }
        String price = initPrice.getText().toString().trim();
        if(price.equals("")) {
            DialogUtil.showDialog(getActivity(),"起拍价格是必填项",false);
            return false;
        }

        Double.parseDouble(price);

        return true;
    }
}
