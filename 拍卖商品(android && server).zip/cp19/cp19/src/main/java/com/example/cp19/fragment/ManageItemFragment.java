package com.example.cp19.fragment;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.cp19.Callbacks;
import com.example.cp19.R;
import com.example.cp19.adapter.JSONArrayAdapter;
import com.example.cp19.listener.HomeListener;
import com.example.cp19.utils.DialogUtil;
import com.example.cp19.utils.HttpUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


@SuppressLint("NewApi")
public class ManageItemFragment extends Fragment {

    public static final int ADD_ITEM = 0X1006;
    Button bnHome,bnAdd;
    ListView itemList;
    Callbacks mCallbacks;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.manage_item,container,false);
        bnHome = (Button) rootView.findViewById(R.id.bn_home);
        bnAdd = (Button) rootView.findViewById(R.id.bnAdd);
        itemList = (ListView) rootView.findViewById(R.id.itemList);
        bnHome.setOnClickListener(new HomeListener(getActivity()));
        bnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCallbacks.onItemSelected(ADD_ITEM,null);
            }
        });
        String url = HttpUtil.BASE_URL + "/item/itemmyself?userId=1  ";
        try {
            JSONArray jsonArray = new JSONArray(HttpUtil.getRequest(url));
            JSONArrayAdapter adapter = new JSONArrayAdapter(getActivity(),jsonArray,"name",true);
            itemList.setAdapter(adapter);
        } catch (Exception e) {
            DialogUtil.showDialog(getActivity(),"服务器响应异常请稍后再试",false);
            e.printStackTrace();
        }

        itemList.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                viewItemInBid(position);
            }
        });
        return rootView;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        if(!(activity instanceof Callbacks)) {
            throw  new IllegalStateException("activity 必须实现Callbacks 接口");
        }
        mCallbacks = (Callbacks) activity;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mCallbacks = null;
    }

    private void viewItemInBid(int position) {
        // 加载detail_in_bid.xml
        View detailView = getActivity().getLayoutInflater().inflate(R.layout.detail_in_bid,null);
        TextView itemName = (TextView) detailView.findViewById(R.id.itemName);
        TextView itemKind = (TextView) detailView.findViewById(R.id.itemKind);
        TextView maxPrice = (TextView) detailView.findViewById(R.id.maxPrice);
        TextView initPrice = (TextView) detailView.findViewById(R.id.initPrice);
        TextView endTime = (TextView) detailView.findViewById(R.id.endTime);
        TextView itemRemark = (TextView) detailView.findViewById(R.id.itemRemark);

        JSONObject jsonObj = (JSONObject) itemList.getAdapter().getItem(position);


        try {
            itemName.setText(jsonObj.getString("name"));
            itemKind.setText(jsonObj.getString("kind"));
            maxPrice.setText(jsonObj.getString("maxPrice"));
            initPrice.setText(jsonObj.getString("initPrice"));
            endTime.setText(jsonObj.getString("endTime"));
            itemRemark.setText(jsonObj.getString("descs"));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        DialogUtil.showDialog(getActivity(),detailView);
    }
}
