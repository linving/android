package com.cp.model;

import java.util.List;

import com.jfinal.plugin.activerecord.Db;

public class KindModel extends BaseModel<KindModel> {

	private static final long serialVersionUID = 4090543224464675470L;

	/**
	 * 物品种类
	 * @return
	 */
	public List<KindModel> listKind() {
		List<KindModel> kind = find("select kind_id id,kind_name kindName,kind_desc kindDesc from kind");
		return kind;
	}
	
	/**
	 * 添加种类
	 */
	public boolean addKind(String[] params) {
		//Record kind = new Record().set("kind_name", params[0]).set("kind_desc", params[1]);
		int update = Db.update("insert into kind(kind_name,kind_desc) values(?,?)", new Object[]{params[0],params[1]});
		return update == 1;
	}
	
	/**
	 * 种类下物品
	 */
	public List<ItemModel> itembykindid(String kid) {
		List<ItemModel> model = new ItemModel().find("select * from item,kind where item.kind_id = kind.kind_id where kind.kind_id=?",kid);
		return model;
	}
}
