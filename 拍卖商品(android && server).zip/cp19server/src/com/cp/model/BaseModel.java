package com.cp.model;


@SuppressWarnings("rawtypes")
public class BaseModel<M extends com.jfinal.plugin.activerecord.Model> extends com.jfinal.plugin.activerecord.Model<M> {

	private static final long serialVersionUID = -1478640461484554366L;

	
}
