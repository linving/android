package com.cp.model;

import java.util.List;
import java.util.Map;

import com.jfinal.plugin.activerecord.Db;

public class ItemModel extends BaseModel<ItemModel> {

	private static final long serialVersionUID = -2823566588288831820L;

	/**
	 * 查看流拍物品
	 */
	public List<ItemModel> viewItem() {
		List<ItemModel> modelItem = find("select item.item_id,item.item_remark remark,item.item_name name,kind.kind_name as kind from item,state,kind where state.state_id = item.state_id and item.kind_id = kind.kind_id");
		return modelItem;
	}
	
	/**
	 * 查看竞得物品
	 */
	public List<ItemModel> itemGiveList() {
		List<ItemModel> modelItem = find("select item.item_id,item.item_remark remark,item.item_name name,kind.kind_name as kind from item,state,kind where state.state_id = item.state_id and item.kind_id = kind.kind_id and state.state_id=2");
		return modelItem;
	}

	/**
	 * 自己拍卖物品(获取拍卖中)
	 */
	public List<ItemModel> itemMySelf(String userId) {
		List<ItemModel> modelItem = find("select item.init_price initPrice,item.item_desc as descs,item.item_remark remark,item.item_name name,auction_user.username owners,state.state_name state,item.max_price maxPrice,item.endTime endTime,kind.kind_name kind,item.addtime addTime from item,auction_user,state,kind where kind.kind_id = item.kind_id and item.state_id = state.state_id and item.owner_id = auction_user.user_id and item.state_id='1' and auction_user.user_id=?",userId);
		return modelItem;
	}
	
	/**
	 * 添加拍卖物品
	 */
	public boolean addItem(Map<String,String> map) {
		int count = Db.update("insert into item(item_id,item_name,item_remark,item_desc,kind_id,init_price,addtime,endtime,max_price,owner_id,state_id) values(4,?,?,?,?,?,?,?,25000,2,1)", new Object[]{map.get("itemName"),map.get("remark"),
									map.get("itemDesc"),map.get("kindId"),map.get("initPrice"),"2015-03-13","2015-03-13"});
		return count == 1;
	}
}
