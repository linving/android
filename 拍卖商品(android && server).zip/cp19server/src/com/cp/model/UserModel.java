package com.cp.model;

public class UserModel extends BaseModel<UserModel> {
	
	private static final long serialVersionUID = 4253087006459229596L;

	private String login = "select count(1) as count from auction_user where username=? and userpass=?";
	
	/**
	 * 用户登录 
	 */
	public boolean login(String username ,String password) {
		UserModel model = findFirst(login, new Object[]{username,password});
		if(model.getLong("count") >= 1) {
			return true;
		} else {
			return false;
		}
	}
	
}
