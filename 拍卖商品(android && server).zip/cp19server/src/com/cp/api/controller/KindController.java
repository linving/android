/**
 * Copyright (c) 2015
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.cp.api.controller;

import java.util.List;

import com.cp.model.KindModel;

/**
 * @author jiazhixin
 */
public class KindController extends BaseController {

	/**
	 * 浏览物品种类
	 */
	public void kindlist() {
		KindModel kindModel = new KindModel();
		List<KindModel> kind = kindModel.listKind();
		renderJson(kind);
	}
	
	/**
	 * 添加物品种类
	 */
	public void addkind() {
		KindModel kindModel = new KindModel();
		String name = getPara("kindName",null);
		String desc = getPara("kindDesc",null);
		String [] param = new String[2];
		param[0] = name;
		param[1] = desc;
		if(kindModel.addKind(param)) {
			renderJson("添加成功");
		} else {
			renderJson("添加失败");
		}
	}
	
	/**
	 * 根据种类id查看拍卖物品
	 */
	public void itembykindid() {
		
	}
}
