/**
 * Copyright (c) 2015
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.cp.api.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cp.model.ItemModel;

/**
 * @author jiazhixin
 */
public class ItemController extends BaseController {

	/**
	 * 查看流拍物品
	 */
	public void itemlist() {
		ItemModel model = new ItemModel();
		List<ItemModel> item = model.viewItem();
		renderJson(item);
	}
	
	/**
	 * 查看竞得物品
	 */
	public void itemgivelist() {
		ItemModel model = new ItemModel();
		List<ItemModel> item = model.itemGiveList();
		renderJson(item);
	}
	
	/**
	 * 浏览自己的拍卖物品
	 */
	public void itemmyself() {
		String userId = getPara("userId",null);
		ItemModel model = new ItemModel();
		List<ItemModel> item = model.itemMySelf(userId);
		renderJson(item);
	}
	
	/**
	 * 添加拍卖物品
	 */
	public void additem() {
		String itemName = getPara("itemName");
		String itemDesc = getPara("itemDesc");
		String remark = getPara("itemRemark");
		String initPrice = getPara("initPrice");
		String kindId = getPara("kindId");
		String avail = getPara("availTime");
		// 获取业务组件
		ItemModel model = new ItemModel();
		
		Map<String,String> map = new HashMap<String,String>();
		map.put("itemName", itemName);
		map.put("itemDesc", itemDesc);
		map.put("remark", remark);
		map.put("initPrice", initPrice);
		map.put("kindId", kindId);
		map.put("avail", avail);
		
		if(model.addItem(map)) {
			renderJson("添加物品成功");
		} else {
			renderJson("添加物品失败");
		}
	}
}
