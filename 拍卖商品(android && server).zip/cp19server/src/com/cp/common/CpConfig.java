package com.cp.common;

import com.cp.model.ItemModel;
import com.cp.model.KindModel;
import com.cp.model.UserModel;
import com.jfinal.config.Constants;
import com.jfinal.config.Handlers;
import com.jfinal.config.Interceptors;
import com.jfinal.config.JFinalConfig;
import com.jfinal.config.Plugins;
import com.jfinal.config.Routes;
import com.jfinal.plugin.activerecord.ActiveRecordPlugin;
import com.jfinal.plugin.druid.DruidPlugin;
import com.jfinal.plugin.ehcache.EhCachePlugin;

public class CpConfig extends JFinalConfig {

	private boolean isLocal = isDevMode();

	@Override
	public void configConstant(Constants me) {
		if (isLocal) {
			me.setDevMode(true);
		}
	}

	@Override
	public void configRoute(Routes me) {
		me.add(new CPRoutes());
	}

	@Override
	public void configPlugin(Plugins me) {
		String jdbcUrl, user, password;
		
        if (isLocal) {
            jdbcUrl = Const.DEV_JDBC_URL;   user = Const.DEV_USER;      password = Const.DEV_PASSWORD;
        } else {
            jdbcUrl = Const.JDBC_URL;       user = Const.USER;          password = Const.PASSWORD;
        }
        
        DruidPlugin ds = new DruidPlugin(jdbcUrl,user,password,"com.mysql.jdbc.Driver");
        
        me.add(ds);
        
        ActiveRecordPlugin arp = new ActiveRecordPlugin(ds);
        if (isLocal) {
            arp.setShowSql(true);
        }
        
        me.add(arp);
        
        arp.addMapping("item", ItemModel.class);
        arp.addMapping("auction_user", UserModel.class);
        arp.addMapping("kind", KindModel.class);
      
        me.add(new EhCachePlugin());
	}

	@Override
	public void configInterceptor(Interceptors me) {
	}

	@Override
	public void configHandler(Handlers me) {
	}

	private boolean isDevMode() {
		String osName = System.getProperty("os.name");
		return osName.indexOf("Windows") != -1;
	}

}
