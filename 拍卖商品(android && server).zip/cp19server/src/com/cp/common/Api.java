package com.cp.common;

public class Api {

	public static final String USER_LOGIN = "http://localhost:8080/cp19server/api/user/login";
	public static final String ITEM = "http://localhost:8080/cp19server/api/item/itemlist";
	public static final String KIND = "http://localhost:8080/cp19server/api/kind/kindlist";
	public static final String MYSELF = "http://localhost:8080/cp19server/api/item/itemmyself";
}
