package com.cp.common;

import com.cp.api.controller.ItemController;
import com.cp.api.controller.KindController;
import com.cp.api.controller.UserController;
import com.jfinal.config.Routes;

public class CPRoutes extends Routes {

	@Override
	public void config() {
		add("/api/user" , UserController.class);
		add("/api/item" , ItemController.class);
		add("/api/kind" , KindController.class);
	}

}
